function [bootstats] = bootstrap_equal_samples_francesco(data,Nreps,level_operations,resampling,N_each_level)
    % bootstrap_equal_samples_francesco Description: 
    % ______________
    %[bootstats] = bootstrap_equal_samples_francesco(data,Nreps,level_operations,resampling,N_each_level)
    % Inputs:
    %   - data: {rat,Ego/allo}{cell}(values within cell)
    %   - Nreps: number of reps
    %   - level_operations:cell array of choice one for each level
    %       options are: 'mean''median''pool''group'. 
    %   - resampling: resampling: array of true or false relating to whether to do
    %   resampling at each level [0 0 0] will do no bootstrapping,
    %       [1 1 1] will bootstrap all levels
    %   - N_each_level: a standard number to sample at each level - put nan
    %   if you wan the same number as was recorded
    % Outputs:
    %   - bootstats: output of bootstrapping (it will be in a cell)
    %           if it was averaged at rat level, this will be Nreps x 1
    %           array of bootstrapped summary statistics
    % ______________
    % Author: Kathrine Clarke 
    % Date: 16-Sep-2025

    % Output help if there are no inputs
    if nargin == 0
       help bootstrap_equal_samples_francesco
       return;
    end
    
    


    bootstats = cell(Nreps,1);
    for r = 1:Nreps
        boot_rats = cell(length(data),2);
        for m = 1:numel(data)

            boot_cells = cell(size(data{m},1),1);
            remove_e = zeros(size(data{m},1),1);
            for e = 1:size(data{m},1)
                d1 = data{m}{e,1};


                if resampling(3) ==1
                    d1 = draw_new(d1,N_each_level(3));

                end
                if iscell(d1)
                    d1 = [d1{:}];
                end
                
                d = {d1};
                m_size = length(d1);
                

                if (m_size < 5 && any(strcmp(level_operations{3},{'mean','median'})))
                    remove_e(e) = 1;
                end
                boot_cells(e,:) = perform_level_operation(d,level_operations{3});
            end
            boot_cells(remove_e==1) = [];
            d = boot_cells;
            d(cellfun(@isempty,d)) = [];
            if resampling(2) == 1
                d = draw_new(d,N_each_level(2));
            end

        
            boot_rats(m) = perform_level_operation(d,level_operations{2});
            
        end
        
        d = boot_rats;
 
        if resampling(1)==1
            d = draw_new(d,N_each_level(1));
        end
        bootstats(r,:) = perform_level_operation(d,level_operations{1});
            
    end
    
    if ~any(strcmp(level_operations{1},{'pool','group'}))
        bootstats = cell2mat(bootstats);
    end
end
function boot = perform_level_operation(d,lo)
   
    if size(d,2)>1
      
         switch lo
            case 'mean'
                boot = {mean(cell2mat(d(:,1)),1,'omitnan')-mean(cell2mat(d(:,2)),1,'omitnan')};
             case 'sum'
                boot = {sum(cell2mat(d(:,1)),1,'omitnan')-sum(cell2mat(d(:,2)),1,'omitnan')};
            case 'median'
                boot = {median(cell2mat(d(:,1)),1,'omitnan')-median(cell2mat(d(:,2)),1,'omitnan')};
            case 'pool'
                boot{1,1} = cell2mat(d(:,1));
                boot{1,2} = cell2mat(d(:,2));
            case 'group'
                boot{1,1} = d(:,1);
                boot{1,2} = d(:,2);
        end
    else
        switch lo
            case 'mean'
                boot = mean(cell2mat(d),1,'omitnan');
            case 'median'
                boot = median(cell2mat(d),1,'omitnan');
            case 'pool'
                
                boot = cell2mat(d);
            case 'group'
                boot = d;
            case 'sum'
                boot = sum(cell2mat(d),1,'omitnan');
            case 'countreal'
                boot = sum(~isnan(cell2mat(d)),1,'omitnan');
        end
        boot = {boot};
    end
end
function d = draw_new(d,Ndraw)
    if isnan(Ndraw)
        Ndraw = size(d,1);
    end

    if size(d,2)>1
        d = d(randi(size(d,1),Ndraw,1),:);
    else
        if ~isempty(d)
            d = d(randi(numel(d),Ndraw,1));
        end
    end
end