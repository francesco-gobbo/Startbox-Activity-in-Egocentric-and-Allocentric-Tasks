


%% %%%%%%%%%%%%%%%% New data tables %%%%%%%%
Folder = 'FRANCESCO/Data_tables';

Phase_group = readtable([Folder '/Phase_Group_dictionary.csv'],'ReadRowNames',true);

Classes = readtable([Folder '/Place_cell_classification.csv']);

Area_Num =  readtable([Folder '/Place_fields_area_and_number.csv']);

Directionality =  readtable([Folder '/Directionality.csv']);

% so we can put it in a heirarchy {animal,allo/ego}{cellID}(whatever)
%   - so i think we want to standardise to draw only one value from each
%   cell, and some standard number of cells, and a standard number of Mice
%   (
animals = Phase_group.Properties.VariableNames;
Nanimals = length(animals);

class_cells = cell(Nanimals,2);
area_cells = cell(Nanimals,2);
Npf_cells = cell(Nanimals,2);
Dir_cells = cell(Nanimals,2);

is_allo_class = strcmp(table2cell(Classes(:,'Ego_Allo')),'Allo');
is_allo_area_Npf = strcmp(table2cell(Area_Num(:,'Ego_Allo')),'Allo');
is_allo_dir = strcmp(table2cell(Directionality(:,'Ego_Allo')),'Allo');
for i = 1:Nanimals
    %class:
    class_id = strcmp(table2cell(Classes(:,'Animal')),animals{i});
    %allo
        a = find(class_id & is_allo_class);
        [u,~,ic] =unique(table2cell(Classes(a,'CellIDS')));
        PCs = table2array(Classes(a,'PlaceCells'));
        allo_cell = arrayfun(@(i) {PCs(ic==i)} ,(1:length(u))');
        class_cells(i,1) = {allo_cell};
    %ego
        e = find(class_id & ~is_allo_class);
        [u,~,ic] =unique(table2cell(Classes(e,'CellIDS')));
        PCs = table2array(Classes(e,'PlaceCells'));
        ego_cell = arrayfun(@(i) {PCs(ic==i)} ,(1:length(u))');
        class_cells(i,2) = {ego_cell};
    %area and numpf
    area_npf_id = strcmp(table2cell(Area_Num(:,'Animal')),animals{i});
    %allo
        a = find(area_npf_id & is_allo_area_Npf);
        [u,~,ic] =unique(table2cell(Area_Num(a,'Cell')));
        area = table2array(Area_Num(a,'FieldSize_cm2_'));
        numpf = table2array(Area_Num(a,'nPlaceFields'));
        
        allo_npf = arrayfun(@(i) {numpf(ic==i)} ,(1:length(u))');
        allo_area = arrayfun(@(i) {area(ic==i)} ,(1:length(u))');
        
        area_cells(i,1) = {allo_area};
        Npf_cells(i,1) = {allo_npf};

    %ego
        e = find(area_npf_id & ~is_allo_area_Npf);
        [u,~,ic] =unique(table2cell(Area_Num(e,'Cell')));
        area = table2array(Area_Num(e,'FieldSize_cm2_'));
        numpf = table2array(Area_Num(e,'nPlaceFields'));
        ego_npf = arrayfun(@(i) {numpf(ic==i)} ,(1:length(u))');
        ego_area = arrayfun(@(i) {area(ic==i)} ,(1:length(u))');
        
        area_cells(i,2) = {ego_area};
        Npf_cells(i,2) = {ego_npf};
    %directionality 
    dir_id = strcmp(table2cell(Directionality(:,'Animal')),animals{i});
    %allo
        a = find(dir_id & is_allo_dir);
        [u,~,ic] =unique(table2cell(Directionality(a,'Cell')));
        d = table2array(Directionality(a,'DirectionIndex'));
        allo_cell = arrayfun(@(i) {d(ic==i)} ,(1:length(u))');
        Dir_cells(i,1) = {allo_cell};
    %ego
        e = find(dir_id & ~is_allo_dir);
        [u,~,ic] =unique(table2cell(Directionality(e,'Cell')));
        d = table2array(Directionality(e,'DirectionIndex'));
        ego_cell = arrayfun(@(i) {d(ic==i)} ,(1:length(u))');
        Dir_cells(i,2) = {ego_cell};
end



%%
Nreps = 1000;
groupnums = [9 200 1];
[class_bootstats] = bootstrap_equal_samples_francesco(class_cells,1000,{'mean','pool','pool'},[1 1 1],groupnums);
[npf_bootstats] = bootstrap_equal_samples_francesco(Npf_cells,1000,{'mean','pool','pool'},[1 1 1],groupnums);
[area_bootstats] = bootstrap_equal_samples_francesco(area_cells,1000,{'mean','pool','pool'},[1 1 1],groupnums);
[dir_bootstats] = bootstrap_equal_samples_francesco(Dir_cells,1000,{'mean','pool','pool'},[1 1 1],groupnums);
%%
figure
subplot(2,2,1)

histogram(class_bootstats,'Normalization','probability');
p = min(sum(class_bootstats<0),sum(class_bootstats>0))/Nreps;
xlabel({'Bootstrapped Difference (Allo - Ego)', 'in Proportion of Place cells'})
ylabel('Proportion of replicates')
title(sprintf('Proportion of place cells (p=%0.3f)',p));

subplot(2,2,2)

histogram(npf_bootstats,'Normalization','probability');
p = min(sum(npf_bootstats<0),sum(npf_bootstats>0))/Nreps;
xlabel({'Bootstrapped Difference (Allo - Ego)', 'in Number of Place fields'})
ylabel('Proportion of replicates')
title(sprintf('Number of Place Fields (p=%0.3f)',p));

subplot(2,2,3)

histogram(area_bootstats,'Normalization','probability')

p = min(sum(area_bootstats<0),sum(area_bootstats>0))/Nreps;
xlabel({'Bootstrapped Difference (Allo - Ego)', 'in Area'})
ylabel('Proportion of replicates')
title(sprintf('Area (p=%0.3f)',p));


subplot(2,2,4)

histogram(dir_bootstats,'Normalization','probability');
p = min(sum(dir_bootstats<0),sum(dir_bootstats>0))/Nreps;
xlabel({'Bootstrapped Difference (Allo - Ego)', ' Directionality Index'})
ylabel('Proportion of replicates')
title(sprintf('Directionality Index (p=%0.3f)',p));
%%


