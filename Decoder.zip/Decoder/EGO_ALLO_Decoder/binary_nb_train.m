function [prior, prob] = binary_nb_train(X, ks, K, alpha)
arguments(Input)
    X (:,:) logical % samples x predictors
    ks double {mustBePositive, mustBeInteger, mustBeVector} % samples
    K (1,1) double {mustBePositive, mustBeInteger}
    alpha (1,1) double {mustBeNonnegative} = 1
end
arguments(Output)
    prior (:,1) double % bins
    prob (:,:) double % bins x predictors
end
n_samp = numel(ks);
assert(size(X,1) == n_samp);
%oh = (1:K)'==reshape(ks, 1, n_samp);
oh = sparse(ks, 1:n_samp, true, K, n_samp);
counts = full(sum(oh,2));
prior = counts ./ n_samp;
prob = (full(oh * X) + alpha) ./ (counts + 2*alpha);
%{
arguments(Input)
    X (:,:) logical % predictors x samples
    ks (:,1) double {mustBePositive, mustBeInteger} % samples
end
arguments(Output)
    prob (:,:) double % predictors x bins
end
n_samp = size(ks,1);

K = max(ks);

oh = ks == (1:K);

k_count = sum(oh,1);

%sum(X(1,:)' & oh, 1)

k_count_on = squeeze(sum(X & reshape(oh, 1, n_samp, K), 2));

prob = (k_count_on + 1) ./ (k_count + 1);

%}
% oh' * X'
