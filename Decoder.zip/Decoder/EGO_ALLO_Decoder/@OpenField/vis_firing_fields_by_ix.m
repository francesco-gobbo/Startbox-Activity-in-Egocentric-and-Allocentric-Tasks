function vis_firing_fields_by_ix(o, ix)
arguments(Input)
    o
    ix double {mustBeVector, mustBePositive, mustBeInteger}
end
[firing_loc, firing_times, total_activity] = o.firing_fields;
firing_loc_sorted = firing_loc(ix);
firing_times_sorted = firing_times(ix);
total_activity_sorted = total_activity(ix);

n_plots = numel(firing_loc_sorted);
if n_plots == 0
    error("no cells are this active: %d events", min_events);
end
side_a = floor(sqrt(n_plots));
side_b = ceil(n_plots/side_a);

figure;
tiledlayout(side_a, side_b, "TileSpacing","loose", "Padding","tight");
for i = 1:numel(firing_loc_sorted)
    nexttile;
    scatter(firing_loc_sorted{i}(:,1), firing_loc_sorted{i}(:,2), 4, firing_times_sorted{i}, "filled");
    axis equal;
    xlim([o.r_bounds(1,1) o.r_bounds(2,1)]);
    ylim([o.r_bounds(1,2) o.r_bounds(2,2)]);
    title("cell: " + ix(i) + " events: " + total_activity_sorted(i));
end
end
