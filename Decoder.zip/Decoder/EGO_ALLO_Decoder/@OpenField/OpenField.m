classdef OpenField
    properties
        T (:,:) double % neurons x frames
        r (:,2) double % position in cm
        FPS (1,1) double % frames per second
        MinSpeed (1,1) double % cm/s minimal speed for inclusion
        MaxSlowTime (1,1) double % s maximum slow time for inclusion

        frames_filt (:,1) logical
        T_filt (:,:) double % neurons x filtered frames
        r_filt (:,2) double % position in cm
        r_bounds (2,2) double % boundaries of the field
    end

    methods
        function o = OpenField(T, r, r_bounds, opt)
            arguments(Input)
                T (:,:) double
                r (:,2) double
                r_bounds (2,2) double % [minx miny; maxx maxy]
                opt.FPS (1,1) double = 20 % Hz
                opt.MinSpeed (1,1) double {mustBePositive} = 2 % cm/s
                opt.MaxSlowTime (1,1) double {mustBePositive} = 1 % s
            end
            o.T = T;
            o.r = r;
            o.r_bounds = r_bounds;
            o.FPS = opt.FPS;
            o.MinSpeed = opt.MinSpeed;
            o.MaxSlowTime = opt.MaxSlowTime;

            %% inclusion based on speed
            velocity = [0 0 ; diff(o.r,1,1) .* o.FPS];
            speed = vecnorm(velocity,2,2);
            speed_smooth = smooth(speed, 7);
            thresh = speed_smooth < o.MinSpeed;
            slowness_change = diff([0;thresh;0]);
            slowness_onset = find(slowness_change==1);
            slowness_offset = find(slowness_change==-1) - 1;
            slowness_duration = (slowness_offset - slowness_onset + 1) ./ o.FPS;
            exclusion = slowness_duration >= opt.MaxSlowTime;
            o.frames_filt = true(size(r,1), 1);
            for i = 1:numel(slowness_onset)
                if exclusion(i)
                    o.frames_filt(slowness_onset(i):slowness_offset(i)) = false;
                end
            end
            o.T_filt = o.T(:, o.frames_filt);
            o.r_filt = o.r(o.frames_filt,:);
        end

        [firing_loc, firing_times, total_activity] = firing_fields(o)
        vis_firing_fields(o, min_events)
        vis_firing_fields_by_ix(o, ix)
        vis_movements(o)
        res = decode(o)

        function T_orig_conv_filt = get_T_conv(o, integ_time)
            integ = round(integ_time .* o.FPS);
            T_orig = o.T;
            T_orig_conv = conv2(full(T_orig), ones(1,integ), "full");
            T_orig_conv = T_orig_conv(:, 1:size(T_orig,2));
            T_orig_conv_filt = T_orig_conv(:,o.frames_filt);
        end
    end
end
