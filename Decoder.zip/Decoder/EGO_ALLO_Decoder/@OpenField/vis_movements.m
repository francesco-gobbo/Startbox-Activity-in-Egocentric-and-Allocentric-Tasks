function vis_movements(o)
figure;
plot(o.r(:,1), o.r(:,2), '-ob');
hold on;
r_masked = o.r;
r_masked(o.frames_filt,:) = nan;
plot(r_masked(:,1), r_masked(:,2), '-or');
xlim([o.r_bounds(1,1) o.r_bounds(2,1)]);
ylim([o.r_bounds(1,2) o.r_bounds(2,2)]);
axis image;
xlabel 'x (cm)';
ylabel 'y (cm)';
legend moving slow Location best
end