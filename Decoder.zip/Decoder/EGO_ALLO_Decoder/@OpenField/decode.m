function res = decode(o)

box_dims = o.r_bounds(2,:) - o.r_bounds(1,:);

n_obs = size(o.r_filt,1);

n_train_obs = round(0.7 * n_obs);
n_left = n_obs - n_train_obs;
n_validation = round(n_left/2);
n_test = n_left - n_validation;

ix_train_start = 1;
ix_train_end = n_train_obs;

ix_validation_start = ix_train_end + 1;
ix_validation_end = ix_validation_start + n_validation - 1;

ix_test_start = ix_validation_end + 1;
ix_test_end = ix_test_start + n_test - 1;
assert(ix_test_end == n_obs);

max_integration_duration = 20; %s
max_integration_frames = ceil(max_integration_duration * o.FPS);
integration_samples = 50;

integration_frames = unique(round(logspace(0,log10(max_integration_frames),integration_samples)));
n_integration_frames = numel(integration_frames);

scale_max = max(box_dims);
%scale_min = 1; % cm
scale_samples = 20;
scales_list = logspace(log10(scale_max)-1.5, log10(scale_max), scale_samples);

r_train = o.r_filt(ix_train_start:ix_train_end,:);
r_validation = o.r_filt(ix_validation_start:ix_validation_end,:);
r_test = o.r_filt(ix_test_start:ix_test_end,:);

rmse_train_ctrl = rmse_ctrl(r_train);
rmse_validation_ctrl = rmse_ctrl(r_validation);
rmse_test_ctrl = rmse_ctrl(r_test);

[rmse_train, rmse_validation] = deal(zeros(n_integration_frames, scale_samples));
mdl = cell(n_integration_frames, scale_samples);
threads;
parfor i = 1:n_integration_frames
    integ = integration_frames(i);

    T_orig = o.T;
    T_orig_conv = conv2(full(T_orig), ones(1,integ), "full");
    T_orig_conv = T_orig_conv(:, 1:size(T_orig,2));
    T_orig_conv_filt = T_orig_conv(:,o.frames_filt);
    T_train = T_orig_conv_filt(:,ix_train_start:ix_train_end);
    T_validation = T_orig_conv_filt(:,ix_validation_start:ix_validation_end);
    for j = 1:scale_samples
        scale = scales_list(j);
        bin_nums = scale2bins(scale, box_dims);
        [~, ks_train, ~] = cont2dpos(r_train, box_dims, bin_nums);
        %[dpos_validation, ks_validation, c_validation] = cont2dpos(r_validation, box_dims, bin_nums);
        
        mdl{i,j} = cnb_train(T_train, ks_train, prod(bin_nums));%fitcnb(double(T_train'~=0), ks_train, CategoricalPredictors="all");
        ks_train_hat = cnb_predict(mdl{i,j}, T_train);
        c_train_hat = ks2centers(ks_train_hat, box_dims, bin_nums);
        ks_validation_hat = cnb_predict(mdl{i,j}, T_validation);
        c_validation_hat = ks2centers(ks_validation_hat, box_dims, bin_nums);

        rmse_train(i,j) = rmse(c_train_hat, r_train);
        rmse_validation(i,j) = rmse(c_validation_hat, r_validation);
        fprintf("%d ", round(j./scale_samples.*100));
    end
    fprintf("| %d\n", round(i./n_integration_frames.*100));
end

[min_rmse_validation, lin_ix_min] = min(rmse_validation, [], "all");
[ix_min_integration, ix_min_scale] = ind2sub(size(rmse_validation), lin_ix_min);
min_rmse_train = rmse_train(ix_min_integration, ix_min_scale);

test_integ = integration_frames(ix_min_integration);
test_scale = scales_list(ix_min_scale);

T_orig = o.T;
T_orig_conv = conv2(full(T_orig), ones(1,test_integ), "full");
T_orig_conv = T_orig_conv(:, 1:size(T_orig,2));
T_orig_conv_filt = T_orig_conv(:, o.frames_filt);
T_test = T_orig_conv_filt(:, ix_test_start:ix_test_end);
bin_nums = scale2bins(test_scale, box_dims);
%[dpos_test, ks_test, c_test] = cont2dpos(r_test, box_dims, bin_nums);
[~, ks_test, ~] = cont2dpos(r_test, box_dims, bin_nums);
mdl_min = mdl{ix_min_integration, ix_min_scale};
ks_test_hat = cnb_predict(mdl_min, T_test);
c_test_hat = ks2centers(ks_test_hat, box_dims, bin_nums);
rmse_test = rmse(c_test_hat, r_test);

res = struct;
res.rmse_test = rmse_test;
res.min_rmse_validation = min_rmse_validation;
res.min_rmse_train = min_rmse_train;
res.test_integ = test_integ;
res.test_scale = test_scale;
res.test_bin_nums = bin_nums;
res.mdl_min = mdl_min;
res.rmse_validation = rmse_validation;
res.rmse_train = rmse_train;
res.integration_frames = integration_frames;
res.scales_list = scales_list;
res.rmse_train_ctrl = rmse_train_ctrl;
res.rmse_validation_ctrl = rmse_validation_ctrl;
res.rmse_test_ctrl = rmse_test_ctrl;

model_predictor_MI = get_model_MI(res.mdl_min.my.prob, res.mdl_min.my.prior);
mdl_test = cnb_train(T_test, ks_test, prod(bin_nums));
KL = get_models_KL(mdl_test.my, res.mdl_min.my);
predictor_score = model_predictor_MI - KL;

res.mdl_test = mdl_test;
res.model_predictor_MI = model_predictor_MI;
res.KL = KL;
res.predictor_score = predictor_score;
end

function KL = get_models_KL(model_p, model_q)
P = get_model_joint_dist(model_p.prob, model_p.prior);
Q = get_model_joint_dist(model_q.prob, model_q.prior);
KL = squeeze(sum(log(P./Q).*P, [1 2]));
end

function P_joint = get_model_joint_dist(prob, prior)
P_joint = prob;
P_joint = reshape(P_joint, 1, size(P_joint,1), size(P_joint,2));
P_joint = [(1-P_joint);P_joint];
P_joint = P_joint .* prior';
end

function MI = get_model_MI(prob, prior)
%{
P_train = prob;
P_train = reshape(P_train, 1, size(P_train,1), size(P_train,2));
P_train = [(1-P_train);P_train];
P_train = P_train .* prior';
%}
P_train = get_model_joint_dist(prob, prior);
MI = squeeze(sum(log(P_train./(sum(P_train,1).*sum(P_train,2))).*P_train, [1 2]));
end

function [dpos, ks, c] = cont2dpos(pos, box_dims, bin_nums)
pos = (pos - 1e-6) ./ box_dims .* bin_nums;
pos(pos < 0) = 0;
dpos = floor(pos) + 1;
ks = sub2ind(bin_nums, dpos(:,1), dpos(:,2));

c = dpos - 0.5;
c = c ./ bin_nums .* box_dims;
end

function c = ks2centers(ks, box_dims, bin_nums)
ks = ks(:);
[i, j] = ind2sub(bin_nums, ks);
dpos = [i j];
c = dpos - 0.5;
c = c ./ bin_nums .* box_dims;
end

function bin_nums = scale2bins(len, box_dims)
bin_nums = max(1, floor(box_dims ./ len));
end

function err = rmse(hat, target)
err = sqrt(mean(sum((hat - target).^2,2),1));
end

function ctrl = rmse_ctrl(target)
ctrl = sqrt(sum(var(target,1)));
end

function mdl = cnb_train(T, ks, max_K)
%mdl.lib = fitcnb(double(T'~=0), ks, CategoricalPredictors="all");
[mdl.my.prior, mdl.my.prob] = binary_nb_train(sparse(T'~=0), ks, max_K);
end
function ks = cnb_predict(mdl, T)
%ks = predict(mdl.lib, double(T'~=0));
[ks_check, post] = binary_nb_predict(mdl.my.prior, mdl.my.prob, sparse(T'~=0));
%assert(all(max(post,[],2) == post(sub2ind(size(post),(1:size(post,1))',ks))));
ks = ks_check;
end
