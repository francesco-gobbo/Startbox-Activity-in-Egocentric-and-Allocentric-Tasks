function [firing_loc, firing_times, total_activity] = firing_fields(o)
arguments(Input)
    o (1,1) OpenField
end
arguments(Output)
    firing_loc (1,:) cell
    firing_times (1,:) cell
    total_activity (1,:) double
end
[n_cells, ~] = size(o.T_filt);
[c_ix, f_ix] = find(o.T_filt);
[firing_times, firing_loc] = deal(cell(1, n_cells));
for i = 1:n_cells
    firing_times{i} = f_ix(c_ix==i);
    firing_loc{i} = o.r_filt(firing_times{i},:);
end
total_activity = full(sum(o.T_filt~=0,2));
end
