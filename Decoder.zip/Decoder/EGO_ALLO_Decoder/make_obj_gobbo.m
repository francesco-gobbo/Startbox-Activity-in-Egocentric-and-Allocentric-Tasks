function [o, cell_vars] = make_obj_gobbo(mouse_name, exp_type, day_num)
arguments(Input)
    mouse_name (1,1) string
    exp_type (1,1) string {mustBeMember(exp_type, ["Allo" "Ego"])}
    day_num (1,1) double {mustBeInRange(day_num, 28, 34), mustBeInteger}
end

switch exp_type
    case "Allo"
        exp_code = "A";
    case "Ego"
        exp_code = "E";
    otherwise
        error("Only Ego and Allo are allowed");
end
%%
listing = dir(mouse_name + "_P*" + exp_type);
assert(isscalar(listing));
dirname = string(listing.name);
%fprintf("Found required mouse and experiment type under: %s\n", dirname);

%%
training_fnames = mouse_name + "_" + exp_code + day_num + "_PRE" + (1:2) + "_events_dlc.csv";
training_files = fullfile(dirname, "Quality_checked", training_fnames);

%%
num_train_files = numel(training_files);
assert(num_train_files == 2);
[rs, ts, Ts, cell_vars_s, ds] = deal(cell(1,num_train_files));
for i = 1:num_train_files
    [rs{i}, ts{i}, Ts{i}, cell_vars_s{i}, ds{i}] = load_csv_mouse_data(training_files(i));
end

%%
[common_cells, sel_1, sel_2] = intersect(cell_vars_s{1}, cell_vars_s{2});
assert(~isempty(common_cells), "no cells in common");
%if ~isequal(cell_vars_s{1}, cell_vars_s{2}) %cells are matched
%    neq_filt = cell_vars_s{1} ~= cell_vars_s{2};
%    warning(join(cell_vars_s{1}(neq_filt), ", ") + " do not match " + join(cell_vars_s{2}(neq_filt), ", "));
%end

r = cat(1, rs{:});
%t = [ts{1}; ts{2} + ts{1}(end) + ts{2}(2)];
%T = cat(2, Ts{:});
T = [Ts{1}(sel_1,:) Ts{2}(sel_2,:)];
cell_vars = common_cells;
%%
r_clean = clean_position(r) ./ 5.2;

%%
o = OpenField(T, r_clean, [0 0; 135 135], FPS=20, MinSpeed=2, MaxSlowTime=1);
