function vis_movements(r,t)
arguments(Input)
    r (:,2) double
    t (:,1) double
end
assert(size(r,1) == size(t,1));
figure;
plot3(r(:,1), r(:,2), t, '.');
axis equal;
xlabel 'x (px)'
ylabel 'y (px)'
zlabel 't (s)'
title 'Motion in space'