access = [
    "om2-0405" "om" "om2" "0405"
    "om2-0407" "om" "om2" "0407"
    "om2-0409" "om" "om2" "0409"
    "om2-0410" "om" "om2" "0410"
    "om3-0327" "om" "om3" "0327"
    "om3-0328" "om" "om3" "0328"
    "om3-0329" "om" "om3" "0329"
    "om3-0404" "om" "om3" "0404"
    "fabio-08" "fabio" "dhpc08" ""
    "fabio-09" "fabio" "dhpc09" ""
    "fabio-10" "fabio" "dhpc10" ""
    "H2222-A-28" "gobbo" "H2222" "Allo:28"
    "H2222-A-29" "gobbo" "H2222" "Allo:29"
    "H2222-A-30" "gobbo" "H2222" "Allo:30"
    "H2222-A-31" "gobbo" "H2222" "Allo:31"
    "H2222-A-32" "gobbo" "H2222" "Allo:32"
    "H2222-A-33" "gobbo" "H2222" "Allo:33"
    "H2222-A-34" "gobbo" "H2222" "Allo:34"
    "H2222-E-28" "gobbo" "H2222" "Ego:28"
    "H2222-E-29" "gobbo" "H2222" "Ego:29"
    "H2222-E-30" "gobbo" "H2222" "Ego:30"
    "H2222-E-31" "gobbo" "H2222" "Ego:31"
    "H2222-E-32" "gobbo" "H2222" "Ego:32"
    "H2222-E-33" "gobbo" "H2222" "Ego:33"
    "H2222-E-34" "gobbo" "H2222" "Ego:34"
    "H2224-A-28" "gobbo" "H2224" "Allo:28"
    "H2224-A-29" "gobbo" "H2224" "Allo:29"
    "H2224-A-30" "gobbo" "H2224" "Allo:30"
    "H2224-A-31" "gobbo" "H2224" "Allo:31"
    "H2224-A-32" "gobbo" "H2224" "Allo:32"
    "H2224-A-33" "gobbo" "H2224" "Allo:33"
    "H2224-A-34" "gobbo" "H2224" "Allo:34"
    "H2224-E-28" "gobbo" "H2224" "Ego:28"
    "H2224-E-29" "gobbo" "H2224" "Ego:29"
    "H2224-E-30" "gobbo" "H2224" "Ego:30"
    "H2224-E-31" "gobbo" "H2224" "Ego:31"
    "H2224-E-32" "gobbo" "H2224" "Ego:32"
    "H2224-E-33" "gobbo" "H2224" "Ego:33"
    "H2224-E-34" "gobbo" "H2224" "Ego:34"
    %"H2225-A-28" "gobbo" "H2225" "Allo:28"
    "H2225-A-29" "gobbo" "H2225" "Allo:29"
    "H2225-A-30" "gobbo" "H2225" "Allo:30"
    "H2225-A-31" "gobbo" "H2225" "Allo:31"
    "H2225-A-32" "gobbo" "H2225" "Allo:32"
    "H2225-A-33" "gobbo" "H2225" "Allo:33"
    "H2225-A-34" "gobbo" "H2225" "Allo:34"
    "H2225-E-28" "gobbo" "H2225" "Ego:28"
    "H2225-E-29" "gobbo" "H2225" "Ego:29"
    "H2225-E-30" "gobbo" "H2225" "Ego:30"
    "H2225-E-31" "gobbo" "H2225" "Ego:31"
    "H2225-E-32" "gobbo" "H2225" "Ego:32"
    "H2225-E-33" "gobbo" "H2225" "Ego:33"
    "H2225-E-34" "gobbo" "H2225" "Ego:34"
    "H2226-A-28" "gobbo" "H2226" "Allo:28"
    "H2226-A-29" "gobbo" "H2226" "Allo:29"
    "H2226-A-30" "gobbo" "H2226" "Allo:30"
    "H2226-A-31" "gobbo" "H2226" "Allo:31"
    "H2226-A-32" "gobbo" "H2226" "Allo:32"
    "H2226-A-33" "gobbo" "H2226" "Allo:33"
    "H2226-A-34" "gobbo" "H2226" "Allo:34"
    "H2226-E-28" "gobbo" "H2226" "Ego:28"
    "H2226-E-29" "gobbo" "H2226" "Ego:29"
    "H2226-E-30" "gobbo" "H2226" "Ego:30"
    "H2226-E-31" "gobbo" "H2226" "Ego:31"
    "H2226-E-32" "gobbo" "H2226" "Ego:32"
    "H2226-E-33" "gobbo" "H2226" "Ego:33"
    "H2226-E-34" "gobbo" "H2226" "Ego:34"
    "H2230-A-28" "gobbo" "H2230" "Allo:28"
    "H2230-A-29" "gobbo" "H2230" "Allo:29"
    "H2230-A-30" "gobbo" "H2230" "Allo:30"
    "H2230-A-31" "gobbo" "H2230" "Allo:31"
    "H2230-A-32" "gobbo" "H2230" "Allo:32"
    "H2230-A-33" "gobbo" "H2230" "Allo:33"
    "H2230-A-34" "gobbo" "H2230" "Allo:34"
    "H2230-E-28" "gobbo" "H2230" "Ego:28"
    "H2230-E-29" "gobbo" "H2230" "Ego:29"
    "H2230-E-30" "gobbo" "H2230" "Ego:30"
    "H2230-E-31" "gobbo" "H2230" "Ego:31"
    "H2230-E-32" "gobbo" "H2230" "Ego:32"
    "H2230-E-33" "gobbo" "H2230" "Ego:33"
    "H2230-E-34" "gobbo" "H2230" "Ego:34"
    "H2231-A-28" "gobbo" "H2231" "Allo:28"
    "H2231-A-29" "gobbo" "H2231" "Allo:29"
    "H2231-A-30" "gobbo" "H2231" "Allo:30"
    "H2231-A-31" "gobbo" "H2231" "Allo:31"
    "H2231-A-32" "gobbo" "H2231" "Allo:32"
    "H2231-A-33" "gobbo" "H2231" "Allo:33"
    "H2231-A-34" "gobbo" "H2231" "Allo:34"
    "H2231-E-28" "gobbo" "H2231" "Ego:28"
    "H2231-E-29" "gobbo" "H2231" "Ego:29"
    "H2231-E-30" "gobbo" "H2231" "Ego:30"
    "H2231-E-31" "gobbo" "H2231" "Ego:31"
    "H2231-E-32" "gobbo" "H2231" "Ego:32"
    "H2231-E-33" "gobbo" "H2231" "Ego:33"
    "H2231-E-34" "gobbo" "H2231" "Ego:34"
    "H2234-A-28" "gobbo" "H2234" "Allo:28"
    "H2234-A-29" "gobbo" "H2234" "Allo:29"
    %"H2234-A-30" "gobbo" "H2234" "Allo:30"
    "H2234-A-31" "gobbo" "H2234" "Allo:31"
    "H2234-A-32" "gobbo" "H2234" "Allo:32"
    "H2234-A-33" "gobbo" "H2234" "Allo:33"
    "H2234-A-34" "gobbo" "H2234" "Allo:34"
    "H2234-E-28" "gobbo" "H2234" "Ego:28"
    "H2234-E-29" "gobbo" "H2234" "Ego:29"
    "H2234-E-30" "gobbo" "H2234" "Ego:30"
    "H2234-E-31" "gobbo" "H2234" "Ego:31"
    "H2234-E-32" "gobbo" "H2234" "Ego:32"
    "H2234-E-33" "gobbo" "H2234" "Ego:33"
    "H2234-E-34" "gobbo" "H2234" "Ego:34"
    %"H2235-A-28" "gobbo" "H2235" "Allo:28"
    %"H2235-A-29" "gobbo" "H2235" "Allo:29"
    %"H2235-A-30" "gobbo" "H2235" "Allo:30"
    %"H2235-A-31" "gobbo" "H2235" "Allo:31"
    %"H2235-A-32" "gobbo" "H2235" "Allo:32"
    %"H2235-A-33" "gobbo" "H2235" "Allo:33"
    %"H2235-A-34" "gobbo" "H2235" "Allo:34"
    "H2235-E-28" "gobbo" "H2235" "Ego:28"
    "H2235-E-29" "gobbo" "H2235" "Ego:29"
    %"H2235-E-30" "gobbo" "H2235" "Ego:30"
    "H2235-E-31" "gobbo" "H2235" "Ego:31"
    "H2235-E-32" "gobbo" "H2235" "Ego:32"
    "H2235-E-33" "gobbo" "H2235" "Ego:33"
    "H2235-E-34" "gobbo" "H2235" "Ego:34"
    "H2241-A-28" "gobbo" "H2241" "Allo:28"
    "H2241-A-29" "gobbo" "H2241" "Allo:29"
    %"H2241-A-30" "gobbo" "H2241" "Allo:30"
    "H2241-A-31" "gobbo" "H2241" "Allo:31"
    "H2241-A-32" "gobbo" "H2241" "Allo:32"
    "H2241-A-33" "gobbo" "H2241" "Allo:33"
    "H2241-A-34" "gobbo" "H2241" "Allo:34"
    "H2241-E-28" "gobbo" "H2241" "Ego:28"
    "H2241-E-29" "gobbo" "H2241" "Ego:29"
    "H2241-E-30" "gobbo" "H2241" "Ego:30"
    "H2241-E-31" "gobbo" "H2241" "Ego:31"
    "H2241-E-32" "gobbo" "H2241" "Ego:32"
    "H2241-E-33" "gobbo" "H2241" "Ego:33"
    "H2241-E-34" "gobbo" "H2241" "Ego:34"
    ];
access = array2table(access,...
    VariableNames=["ID" "Set" "MouseName" "SessLabel"]);

n_rows = size(access,1);
[rmse_test, rmse_test_ctrl] = deal(zeros(n_rows, 1));
for i = 1:n_rows
    save_file = sprintf("decode_%s.mat", access.ID(i));
    if ~isfile(save_file)
        set_val = access.Set(i);
        switch set_val
            case "om"
                obj = make_obj_om(access.MouseName(i), access.SessLabel(i), UseEvents=true);
            case "fabio"
                obj = make_obj_fabio(access.MouseName(i));
            case "gobbo"
                lab = access.SessLabel(i).split(":");
                assert(numel(lab) == 2);
                obj = make_obj_gobbo(access.MouseName(i), lab(1), lab(2));
            otherwise
                error("only om, fabio, and gobbo supported");
        end
        res = obj.decode;
        save("-v7.3", save_file, "-struct", "res");
    else
        res = load(save_file);
    end
    rmse_test(i) = res.rmse_test;
    rmse_test_ctrl(i) = res.rmse_test_ctrl;
end
%%
figure;
bar(access.ID, [rmse_test rmse_test_ctrl]);
xlabel Session
ylabel 'RMSE decoding test error (cm)'
legend test constant

%%
filt = access.MouseName.startsWith("H");
figure;
boxplot(rmse_test(filt), access.MouseName(filt), Colors="b");
hold on;
boxplot(rmse_test_ctrl(filt), access.MouseName(filt), Colors="r");
xlabel Animal
ylabel 'RMSE decoding test error (cm)'
text(9,90,"constant",Color="r",HorizontalAlignment="right");
text(9,95,"test",color="b",HorizontalAlignment="right");
fontname("Arial");

tab = table(rmse_test(filt), rmse_test_ctrl(filt), access.MouseName(filt), VariableNames=["RMSE_test" "RMSE_constant" "Animal"]);
writetable(tab, fullfile("figs", "decoder_test_by_rat.csv"));
savefig(fullfile("figs", "decoder_test_by_rat.fig"));
print(gcf, "-dsvg", fullfile("figs", "decoder_test_by_rat.svg"));
%%
figure;
rmse_diff = rmse_test - rmse_test_ctrl;
boxplot(rmse_diff(filt), access.MouseName(filt));
yline(0);
xlabel Animal
ylabel '\DeltaRMSE decoding test error (cm)'
title 'test - control'
%%
rat_names = unique(access.MouseName(filt));
[p,h] = deal(zeros(numel(rat_names),1));
for i = 1:numel(rat_names)
    [p(i), h(i)] = signrank(rmse_diff(access.MouseName == rat_names(i)), 0, tail="left");
end
disp(table(rat_names,p,h));
%%
ixs = find(p < 0.05);
for j = 1:numel(ixs)
    text(ixs(j), 30, pstar(p(ixs(j))), HorizontalAlignment="center");
end
%%
fontname("Arial");
tab = table(rmse_diff(filt), access.MouseName(filt), VariableNames=["RMSE_test_minus_constant" "Animal"]);
writetable(tab, fullfile("figs", "decoder_test_by_rat_diff.csv"));
tab = table(rat_names,p,h);
writetable(tab, fullfile("figs", "decoder_test_by_rat_diff_significance.csv"));
savefig(fullfile("figs", "decoder_test_by_rat_diff.fig"));
print(gcf, "-dsvg", fullfile("figs", "decoder_test_by_rat_diff.svg"));