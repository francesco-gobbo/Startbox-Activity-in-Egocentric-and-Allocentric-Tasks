rat_names = ["H2222" "H2224", "H2225", "H2226", "H2230", "H2231", "H2234", "H2235", "H2241"];

exp_types = ["Allo" "Ego"];

num_rats = numel(rat_names);
num_exp_types = numel(exp_types);

is_available = any(isfolder(rat_names' + "_P" + cat(3,1,2) + exp_types),3);
result_tables = cell(num_rats, num_exp_types);
%%
for rat_ix = 1:num_rats
    animal = rat_names(rat_ix);
    for exp_type_ix = 1:num_exp_types
        exp_type = exp_types(exp_type_ix);
        if ~isequal(result_tables{rat_ix,exp_type_ix}, [])
            continue;
        end
        if is_available(rat_ix, exp_type_ix)
            t_ = tic;
            result_tables{rat_ix, exp_type_ix} = apply_decoders(animal, exp_type);
            fprintf("Done: rat %d/%d exp type %d/%d in %.4g s\n", rat_ix, num_rats, exp_type_ix, num_exp_types, toc(t_));
            disp(size(result_tables{rat_ix, exp_type_ix}));
        else
            fprintf("Not available: rat %d/%d exp type %d/%d\n", rat_ix, num_rats, exp_type_ix, num_exp_types);
        end
    end
end

save -v7.3 result_tables_save.mat result_tables rat_names exp_types
