function res = tab_pad(varargin)
v = cellfun(@(x)x(:), varargin, UniformOutput=false);
n = max(cellfun(@numel, v));
v = cellfun(@(x)padarray(x,n-numel(x),NaN,"post"), v, UniformOutput=false);
res = cat(2,v{:});