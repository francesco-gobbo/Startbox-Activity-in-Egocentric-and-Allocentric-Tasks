function o = make_obj_om(mouse_name, day_code, opt)
arguments(Input)
    mouse_name (1,1) string = "om2"
    day_code (1,1) string = "0410"
    opt.UseEvents (1,1) logical = true
end

root_dir = "C:\Users\Omer\Documents\lab_data\open_field";

fps = 20;

sess_code = mouse_name + "-" + day_code;
sess_dir = fullfile(root_dir, sess_code);

r = load(fullfile(sess_dir, "_data", sess_code + ".xy"));

r_sc = r ./ 22; % to cm
r_sc = r_sc - min(r_sc);

S = dir(fullfile(sess_dir, "cm01-fix", "rec_*.mat"));
assert(isscalar(S));
recfile = fullfile(S.folder, S.name);

con = load(recfile);

T = con.traces';
T = T ./ max(T,[],2);

%
S = dir(fullfile(sess_dir, "cm01-fix", "events_*.mat"));
assert(isscalar(S));
events_file = fullfile(S.folder, S.name);
load(events_file, "events");
num_cells = numel(events);
assert(num_cells == size(T,1));
num_frames = events(1).info.num_frames;
assert(num_frames == size(T,2));

T_ev = zeros(num_cells, num_frames);
for i = 1:num_cells
    if ~isempty(events(i).auto)
        on = events(i).auto(:,1);
        on = on(isfinite(on));
        T_ev(i, on) = 1;
    end
end

if opt.UseEvents
    T = T_ev;
end
o = OpenField(T, r_sc, [min(r_sc);max(r_sc)], FPS=fps);