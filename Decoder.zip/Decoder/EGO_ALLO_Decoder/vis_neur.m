function vis_neur(T, t)
[n_cells, n_frames] = size(T);
assert(numel(t) == n_frames);
figure;
imagesc(t, 1:n_cells, T~=0);
xlabel 't (s)'
ylabel 'Neurons'