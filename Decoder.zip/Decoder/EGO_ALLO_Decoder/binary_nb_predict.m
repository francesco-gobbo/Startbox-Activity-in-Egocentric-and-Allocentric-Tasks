function [ks, post] = binary_nb_predict(prior, prob, X)
arguments(Input)
    prior (:,1) double % bins
    prob (:,:) double % bins x predictors
    X (:,:) logical % samples x predictors
end
arguments(Output)
    ks (:,1) double {mustBePositive, mustBeInteger} % samples
    post
end
n_samp = size(X,1);
prob = prob';
lp = log(prob);
lnp = log(1-prob);
lp_m_lnp = lp - lnp;
%for i = 1:n_samp
%    [~, ks(i)] = max(sum(lnp,2) + sum(lp_m_lnp(:,X(i,:)),2),[],1);
%end
post = log(prior') + sum(lnp,1) + X * lp_m_lnp;
[~, ks] = max(post,[],2);
