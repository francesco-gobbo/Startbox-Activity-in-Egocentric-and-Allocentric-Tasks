function r = clean_position(r)
r = min(700, max(0, r));