set(0, DefaultUicontrolFontName="Arial");
set(0, DefaultUitableFontName="Arial");
set(0, DefaultAxesFontName="Arial");
set(0, DefaultTextFontName="Arial");
set(0, DefaultUipanelFontName="Arial");