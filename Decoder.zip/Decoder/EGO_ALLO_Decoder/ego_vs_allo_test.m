load result_tables_save.mat

%%
num_rats = numel(rat_names);

lab = @(p) sprintf(" p=%.1g (%s)", p, pstar(p));
bw = 5;
for rat_ix = 1:num_rats
    figure(Position=[381         111        1328         808]);
    tiledlayout(3,3);
    res_allo = result_tables{rat_ix,1};
    res_ego = result_tables{rat_ix,2};

    dist_type = ["RMSDist" "MeanDist" "MinDist"];
    dist_desc = ["RMS" "Mean" "Min"];
    tab_vars = cell(1, numel(dist_type));
    for j = 1:numel(dist_type)
        tab_vars{j} = struct;
        if isempty(res_allo)
            allo_dist = [];
            allo_dist_correct = [];
            allo_dist_incorrect = [];
            tab_vars{j}.allo_correct = [];
            tab_vars{j}.allo_incorrect = [];
        else
            allo_dist = res_allo.(dist_type(j));
            allo_dist_correct = allo_dist(res_allo.Status=="Correct");
            allo_dist_incorrect = allo_dist(res_allo.Status=="Incorrect");
            tab_vars{j}.allo_correct = allo_dist_correct;
            tab_vars{j}.allo_incorrect = allo_dist_incorrect;
        end
        if isempty(res_ego)
            res_ego = [];
            ego_dist_correct = [];
            ego_dist_incorrect = [];
            tab_vars{j}.ego_correct = [];
            tab_vars{j}.ego_incorrect = [];
        else
            ego_dist = res_ego.(dist_type(j));
            ego_dist_correct = ego_dist(res_ego.Status=="Correct");
            ego_dist_incorrect = ego_dist(res_ego.Status=="Incorrect");
            tab_vars{j}.ego_correct = ego_dist_correct;
            tab_vars{j}.ego_incorrect = ego_dist_incorrect;
        end

        ax(j,1) = nexttile;
        if ~isempty(allo_dist_correct) || ~isempty(allo_dist_incorrect)
            histogram(allo_dist_correct, BinWidth=bw, FaceColor="b");
            hold on;
            histogram(allo_dist_incorrect, BinWidth=bw, FaceColor="m");
            p = ranksum(allo_dist_correct, allo_dist_incorrect, tail="left");
            legend correct incorrect;
            legend(Location="best", Box="off");
            xlabel(dist_desc(j) + " distance from goal (cm)");
            ylabel("# Trials");
            title("Allo correct vs incorrect" + lab(p));
        end

        ax(j,2) = nexttile;
        if ~isempty(ego_dist_correct) || ~isempty(ego_dist_incorrect)
            histogram(ego_dist_correct, BinWidth=bw, FaceColor="g");
            hold on;
            histogram(ego_dist_incorrect, BinWidth=bw, FaceColor="y");
            p = ranksum(ego_dist_correct, ego_dist_incorrect, tail="left");
            legend correct incorrect;
            legend(Location="best", Box="off");
            xlabel(dist_desc(j) + " distance from goal (cm)");
            ylabel("# Trials");
            title("Ego correct vs incorrect" + lab(p));
        end

        ax(j,3) = nexttile;
        if ~isempty(allo_dist_correct) && ~isempty(ego_dist_correct)
            histogram(allo_dist_correct, BinWidth=bw, FaceColor="b");
            hold on;
            histogram(ego_dist_correct, BinWidth=bw, FaceColor="g");
            p = ranksum(allo_dist_correct, ego_dist_correct, tail="left");
            legend allo ego;
            legend(Location="best", Box="off");
            xlabel(dist_desc(j) + " distance from goal (cm)");
            ylabel("# Trials");
            title("Allo vs Ego correct" + lab(p));
        end
    end
    sgtitle(rat_names(rat_ix));
    linkaxes(ax);
    fontname("Arial");
    tab = array2table(tab_pad(tab_vars{1}.allo_correct, tab_vars{1}.allo_incorrect, tab_vars{1}.ego_correct, tab_vars{1}.ego_incorrect,   tab_vars{2}.allo_correct, tab_vars{2}.allo_incorrect, tab_vars{2}.ego_correct, tab_vars{2}.ego_incorrect,  tab_vars{3}.allo_correct, tab_vars{3}.allo_incorrect, tab_vars{3}.ego_correct, tab_vars{3}.ego_incorrect), ...
        VariableNames=["RMS_Allo_Correct" "RMS_Allo_Incorrect" "RMS_Ego_Correct" "RMS_Ego_Incorrect"  "Mean_Allo_Correct" "Mean_Allo_Incorrect" "Mean_Ego_Correct" "Mean_Ego_Incorrect"  "Min_Allo_Correct" "Min_Allo_Incorrect" "Min_Ego_Correct" "Min_Ego_Incorrect"]);
    writetable(tab, fullfile("figs", rat_names(rat_ix) + "_allo_ego_test.csv"));
    savefig(fullfile("figs", rat_names(rat_ix) + "_allo_ego_test.fig"));
    print(gcf, "-dsvg", fullfile("figs",rat_names(rat_ix) + "_allo_ego_test.svg"));
end

%%

chosen_rat_ix = [2 3 4 6];

dist_type = ["RMSDist" "MeanDist" "MinDist"];
dist_desc = ["RMS" "Mean" "Min"];

for i = 1:numel(dist_type)
    dt = dist_type(i);
    dd = dist_desc(i);

    allo = result_tables(chosen_rat_ix,1);
    allo_dist_correct = cellfun(@(x)median(x.(dt)(x.Status=="Correct")), allo);
    allo_dist_incorrect = cellfun(@(x)median(x.(dt)(x.Status=="Incorrect")), allo);

    ego = result_tables(chosen_rat_ix,2);
    ego_dist_correct = cellfun(@(x)median(x.(dt)(x.Status=="Correct")), ego);
    ego_dist_incorrect = cellfun(@(x)median(x.(dt)(x.Status=="Incorrect")), ego);

    marking = @(x,val) errorbar(x,mean(val),0,"r",CapSize=20,LineWidth=3);

    figure;
    hold on;
    marking(1,allo_dist_correct); marking(2,allo_dist_incorrect); plot([1 2], [allo_dist_correct allo_dist_incorrect], "k-o");
    marking(3,ego_dist_correct); marking(4,ego_dist_incorrect); plot([3 4], [ego_dist_correct ego_dist_incorrect], "k-o");
    marking(5,allo_dist_correct); marking(6, ego_dist_correct); plot([5 6], [allo_dist_correct ego_dist_correct], "k-o");

    xlim([0 7]);
    xticks([1 2 3 4 5 6]);
    xticklabels(["Correct Allo" "Incorrect Allo" "Correct Ego" "Incorrect Ego" "Correct Allo" "Correct Ego"]);
    ylabel(dd + " distance from goal (cm)");
    
    fontname("Arial");

    tab = table(allo_dist_correct, allo_dist_incorrect, ego_dist_correct, ego_dist_incorrect, VariableNames=[("Median_Allo_"+dd+"_Correct") ("Median_Allo_"+dd+"_Incorrect") ("Median_Ego_"+dd+"_Correct") ("Median_Ego_"+dd+"_Incorrect")]);
    writetable(tab, fullfile("figs", "summary_all_" + dd + ".csv"));
    savefig(fullfile("figs", "summary_all_" + dd + ".fig"));
    print(gcf, "-dsvg", fullfile("figs", "summary_all_" + dd + ".svg"));
end