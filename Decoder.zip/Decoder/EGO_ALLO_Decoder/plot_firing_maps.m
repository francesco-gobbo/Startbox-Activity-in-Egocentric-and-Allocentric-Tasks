function plot_firing_maps(high_firing_loc)
figure;
tiledlayout("flow");
for i = 1:numel(high_firing_loc)
    nexttile;
    plot(high_firing_loc{i}(:,1), high_firing_loc{i}(:,2), ".");
    xlim([0 135]);
    ylim([0 135]);
    axis square;
end