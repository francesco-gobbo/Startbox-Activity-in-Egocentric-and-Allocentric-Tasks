function [res, high_firing_loc] = decoding_analysis(mouse_name, exp_type, day_num)
arguments(Input)
    mouse_name (1,1) string
    exp_type (1,1) string {mustBeMember(exp_type, ["Allo" "Ego"])}
    day_num (1,1) double {mustBeInRange(day_num, 28, 34), mustBeInteger}
end
%mouse_name = "H2241";
%exp_type = "Allo";
%day_num = "34";

switch exp_type
    case "Allo"
        exp_code = "A";
    case "Ego"
        exp_code = "E";
    otherwise
        error("Only Ego and Allo are allowed");
end
%%
listing = dir(mouse_name + "_P*" + exp_type);
assert(isscalar(listing));
dirname = string(listing.name);
fprintf("Found required mouse and experiment type under: %s\n", dirname);

%%
training_fnames = mouse_name + "_" + exp_code + day_num + "_PRE" + (1:2) + "_events_dlc.csv";
training_files = fullfile(dirname, "Quality_checked", training_fnames);

%%
num_train_files = numel(training_files);
assert(num_train_files == 2);
[rs, ts, Ts, cell_vars_s, ds] = deal(cell(1,num_train_files));
for i = 1:num_train_files
    [rs{i}, ts{i}, Ts{i}, cell_vars_s{i}, ds{i}] = load_csv_mouse_data(training_files(i));
end
%%
[common_cells, sel_1, sel_2] = intersect(cell_vars_s{1}, cell_vars_s{2});
assert(~isempty(common_cells), "no cells in common");
%if ~isequal(cell_vars_s{1}, cell_vars_s{2}) %cells are matched
%    neq_filt = cell_vars_s{1} ~= cell_vars_s{2};
%    warning(join(cell_vars_s{1}(neq_filt), ", ") + " do not match " + join(cell_vars_s{2}(neq_filt), ", "));
%end

r = cat(1, rs{:});
t = [ts{1}; ts{2} + ts{1}(end) + ts{2}(2)];
%T = cat(2, Ts{:});
T = [Ts{1}(sel_1,:) Ts{2}(sel_2,:)];
cell_vars = common_cells;

%%
r_clean = clean_position(r);
%%
dt = 0.05; %s, 20Hz data
integ_time = 2.2; %s % was 0.5
integ_frames = integ_time ./ dt;

T_conv = conv2(full(T), ones(1,integ_frames), "same");
T_conv_pred = T_conv';
%% predictors are T_conv_pred, responses are r_clean
px_per_cm = 5.2; % px / cm
r_cm = r ./ px_per_cm; % 5.2 px / cm
s_len = 135; %cm
gap = 10; %cm
out_of_bounds = any(r_cm < -gap | r_cm > s_len + gap,2);
fps = 20; % Hz
velocity = diff(r_cm,1,1) .* fps; % cm/s
speed = [0;vecnorm(velocity,2,2)]; % cm/s
min_speed = 2; %cm/s

speed_smooth = smooth(speed, 7);
thresh = speed_smooth < min_speed;
% if the speed is under the threshold for more than one second, then
% exclude that entire time block from the data
slowness_change = diff([0;thresh;0]);
slowness_onset = find(slowness_change==1);
slowness_offset = find(slowness_change==-1) - 1;
slowness_duration = (slowness_offset - slowness_onset + 1) ./ fps; %s
exclusion = slowness_duration >= 1; %s
frames_filt = true(size(r,1),1);
for i = 1:numel(slowness_onset)
    if exclusion(i)
        frames_filt(slowness_onset(i):slowness_offset(i)) = false;
    end
end
%%
r_clean_cm = r_clean ./ px_per_cm;
r_clean_cm_filt = r_clean_cm(frames_filt,:);

T_conv_pred_filt = T_conv_pred(frames_filt,:);
T_pred_filt = T(:,frames_filt)';

%% place fields
[n_frames, n_cells] = size(T_pred_filt);
[f_ix, c_ix] = find(T_pred_filt);
firing_loc = cell(1, n_cells);
for i = 1:n_cells
    firing_loc{i} = r_clean_cm_filt(f_ix(c_ix==i),:);
end
%%
high_act_cells = sum(T_pred_filt~=0,1) >= 10;
high_firing_loc = firing_loc(high_act_cells);
%%
%{
figure;
tiledlayout("flow");
for i = 1:numel(high_firing_loc)
    nexttile;
    plot(high_firing_loc{i}(:,1), high_firing_loc{i}(:,2), ".");
    xlim([0 135]);
    ylim([0 135]);
    axis square;
end
%}
%%
bin_side = 10; % cm
r_ints = round(r_clean_cm_filt./bin_side) + 1;
sz = max(r_ints);
ks = sub2ind(sz, r_ints(:,1), r_ints(:,2));
X = double(T_conv_pred_filt~=0);
ix_part = round(n_frames*0.7);

X_train = X(1:ix_part,:);
ks_train = ks(1:ix_part);
r_train = r_clean_cm_filt(1:ix_part,:);

X_test = X(ix_part+1:end,:);
ks_test = ks(ix_part+1:end);
r_test = r_clean_cm_filt(ix_part+1:end,:);
t_ = tic;
mdl = fitcnb(X_train, ks_train, "CategoricalPredictors","all");
fprintf("Done training: ");
toc(t_);
%%
t_ = tic;
ks_train_hat = predict(mdl, X_train);
ks_hat = predict(mdl, X_test);
fprintf("Done prediction: ");
toc(t_);
%% train eval
[r_ints_train_hat(:,1), r_ints_train_hat(:,2)] = ind2sub(sz, ks_train_hat);
r_train_hat = (r_ints_train_hat - 0.5).*bin_side;
rmse_train = sqrt(mean(sum((r_train_hat - r_train).^2,2),1));
%% test eval
[r_ints_hat(:,1), r_ints_hat(:,2)] = ind2sub(sz, ks_hat);
r_hat = (r_ints_hat - 0.5).*bin_side;
rmse = sqrt(mean(sum((r_hat - r_test).^2,2),1));
%% controls
arena_side = 135;
rmse_const = sqrt(mean(sum((arena_side.*[1 1]./2 - r_test).^2,2),1));
rmse_rand = sqrt(mean(sum((rand(size(r_test)).*arena_side - r_test).^2,2),1));
rmse_perm = sqrt(mean(sum((r_test(randperm(size(r_test,1)),:) - r_test).^2,2),1));
%%
fprintf("===Controls===\n");
fprintf("Permutation prediction control RMSE:\t%.2f cm\n", rmse_perm);
fprintf("Uniform random prediction control RMSE:\t%.2f cm\n", rmse_rand);
fprintf("Constant prediction control RMSE:\t\t%.2f cm\n", rmse_const);
fprintf("===Training===\n");
fprintf("Training set RMSE:\t%.2f cm\n", rmse_train );
fprintf("===Testing===\n");
fprintf("Test set RMSE:\t%.2f cm\n", rmse);
%%
res = struct(rmse_test=rmse, rmse_train=rmse_train, rmse_const=rmse_const, rmse_rand=rmse_rand, rmse_perm=rmse_perm, cell_vars=cell_vars);