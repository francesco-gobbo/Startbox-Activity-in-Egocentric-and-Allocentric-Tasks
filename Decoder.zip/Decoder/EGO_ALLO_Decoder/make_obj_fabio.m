function o = make_obj_fabio(mouse_name)
arguments(Input)
    mouse_name (1,1) string {mustBeMember(mouse_name, ["dhpc08" "dhpc09" "dhpc10"])}
end

root_dir = "C:\Users\Omer\Documents\lab_data\fabio_data";

fps = 5;
if ismember(mouse_name, ["dhpc09" "dhpc10"])
    load(fullfile(root_dir, mouse_name + "_cnmfe.mat"), "results");
    T = results.S;
else
    load(fullfile(root_dir, "dhpc08_cnmfe_spikes.txt"));
    T = dhpc08_cnmfe_spikes;
end
[~, n_frames] = size(T);

load(fullfile(root_dir, "adapted", mouse_name + "_behavior.mat"), "points");

behavior = readtable(fullfile(root_dir, mouse_name + "_behavior.txt"));
t = behavior.RecordingTime;
x = behavior.XCenter;
y = behavior.YCenter;
keep = ~isnan(t) & ~isnan(x) & ~isnan(y);
t = t(keep);
x = x(keep);
y = y(keep);

t_query = (1:n_frames).' / fps;
x_query = interp1(t, x, t_query, "linear", "extrap");
y_query = interp1(t, y, t_query, "linear", "extrap");

r = [x_query y_query];


v1 = points{1} - points{2};
v2 = points{3} - points{2};
u2 = v2 - dot(v1,v2).*v1./norm(v1).^2;
c_nw = points{1};
c_sw = points{2};
c_se = u2 + c_sw;
c_ne = u2 + c_nw;
get_x = @(p) (p - c_sw) * (c_se - c_sw).' ./ norm(c_se - c_sw);
get_y = @(p) (p - c_sw) * (c_nw - c_sw).' ./ norm(c_nw - c_sw);
x_new = get_x(r);
y_new = get_y(r);
max_x = get_x(c_ne);
max_y = get_y(c_ne);
x_new(x_new < 0) = 0;
x_new(x_new > max_x) = max_x;
y_new(y_new < 0) = 0;
y_new(y_new > max_y) = max_y;
r = [x_new y_new]; %updated orthogonal position

o = OpenField(T, r, [0 0; max_x max_y], FPS=fps, MinSpeed=2, MaxSlowTime=1);
end