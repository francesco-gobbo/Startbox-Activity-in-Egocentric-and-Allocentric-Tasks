function result_table = apply_decoders(animal, exp_type, opt)
arguments(Input)
    animal (1,1) string {mustBeMember(animal, ["H2222" "H2224", "H2225", "H2226", "H2230", "H2231", "H2234", "H2235", "H2241"])}
    exp_type (1,1) string {mustBeMember(exp_type, ["Allo" "Ego"])}
    opt.Plot (1,1) logical = false
end
arguments(Output)
    result_table (:,:) table
end
%animal = "H2231";
%exp_type = "Allo";

root_dir = "C:\Users\Omer\Documents\lab_data\gobbo";
listing = dir(fullfile(root_dir, animal + "_P?" + exp_type));
assert(isscalar(listing));
dir_name = fullfile(listing.folder, listing.name);
all_trials_fname = fullfile(dir_name, "Quality_checked", animal + "_all_trials.csv");

%%
[r, t, T, cell_var, d] = load_csv_mouse_data(all_trials_fname);%("H2231_P2Allo\Quality_checked\H2231_all_trials.csv");

%%
loc_column = string(d.Location);
trial_start_frames = find(loc_column == "Trial start");

%%

fps = 20;
look_behind = ceil(10 * fps); % 10 seconds in frames

pre_trial_start = trial_start_frames - look_behind + 1;

%%
% example, first one
%trial_ix = 1;
num_trials = numel(pre_trial_start);
[rmse_to_reward, mean_dist_to_reward, min_dist_to_reward, rewarded_well_col] = deal(zeros(num_trials,1));
[status_col, stage_col, sess_col, sess_type_col, sess_day_label_col] = deal(strings(num_trials,1));
keep_rows = false(num_trials, 1);
for trial_ix = 1:num_trials
    frame_start = pre_trial_start(trial_ix);
    frame_end = trial_start_frames(trial_ix);

    T_sub = T(:, frame_start:frame_end);
    remove_cells = any(isnan(T_sub),2);
    my_cell_var = cell_var(~remove_cells);
    T_sub = T_sub(~remove_cells,:);

    %r_sub = r(frame_start:frame_end,:);
    %%
    %{
    figure; plot(r(:,1), r(:,2), '.'); axis equal
    hold on;
    plot(r_sub(:,1), r_sub(:,2), 'r.');
    %}
    %%
    d_sub = d(frame_start:frame_end, :);

    status = string(d_sub.("Trial Status"));
    %assert(all((status(1)==status) | ("0"==status)));
    status = status(end);

    rewarded_well = d_sub.("Rewarded well");
    %assert(all(rewarded_well(1)==rewarded_well));
    rewarded_well = rewarded_well(end);

    stage = string(d_sub.Stage(end));

    sess = string(d_sub.Session(end));
    
    sess_type = sess.extract(1);
    switch exp_type
        case "Allo"
            assert(sess_type == "A");
        case "Ego"
            assert(sess_type == "E");
        otherwise
            error("unsupported %s", exp_type);
    end
    sess_day_label = sess.extractAfter(1);
    decoder_save_fname = "decode_" + animal + "-" + sess_type + "-" + sess_day_label + ".mat";
    if ~isfile(decoder_save_fname) %, "not a file: %s", decoder_save_fname);
        continue;
    end
    decoder_save = load(decoder_save_fname);
    %%
    [pre_obj, cell_vars] = make_obj_gobbo(animal, exp_type, double(sess_day_label));
    %%
    [~, ix_pre, ix_post] = intersect(cell_vars, my_cell_var); %first return arg was cell_vars_combo

    imported_mdl.prior = decoder_save.mdl_min.my.prior;
    imported_mdl.prob = decoder_save.mdl_min.my.prob(:, ix_pre);

    T_sub = T_sub(ix_post,:);
    T_sub_conv = conv2(full(T_sub), ones(1,decoder_save.test_integ), "full");
    T_sub_conv = T_sub_conv(:, 1:size(T_sub,2));
    X = (T_sub_conv~=0)';
    ks_hat = binary_nb_predict(imported_mdl.prior, imported_mdl.prob, X);
    box_dims = pre_obj.r_bounds(2,:) - pre_obj.r_bounds(1,:);
    c_hat = ks2centers(ks_hat, box_dims, decoder_save.test_bin_nums);

    %% detect rewarded well locations: KEEP COMMENT
    %{
    r_clean_test = r./5.2;
    
    figure;
    plot(r_clean_test(:,1), r_clean_test(:,2), ".");
    hold on;
    is_correct = d.("Trial Status") == "Correct";
    plot(r_clean_test(is_correct,1), r_clean_test(is_correct,2), "r.");
    axis equal;
    %}
    %% well locations:

    r_clean_well = cell(1,6);
    r_clean_well{1} = [26 28];
    r_clean_well{2} = [107 28];
    r_clean_well{3} = [48 68];
    r_clean_well{4} = [88 68];
    r_clean_well{5} = [29 107];
    r_clean_well{6} = [108 108];

    %%
    distances_to_reward = vecnorm(r_clean_well{rewarded_well} - c_hat,2,2);
    rmse_to_reward(trial_ix) = sqrt(mean(distances_to_reward.^2,1));
    mean_dist_to_reward(trial_ix) = mean(distances_to_reward,1);
    min_dist_to_reward(trial_ix) = min(distances_to_reward,[],1);
    %fprintf("RMS dist to reward location:\t%.3g cm\n", rmse_to_reward);
    %fprintf("Mean dist to reward location:\t%.3g cm\n", mean_dist_to_reward);
    %fprintf("Min dist to reward location:\t%.3g cm\n", min_dist_to_reward);
    
    status_col(trial_ix) = status;
    rewarded_well_col(trial_ix) = rewarded_well;
    stage_col(trial_ix) = stage;
    sess_col(trial_ix) = sess;
    sess_type_col(trial_ix) = sess_type;
    sess_day_label_col(trial_ix) = sess_day_label;

    %% visualizing prediction
    if opt.Plot
        pre_obj.vis_movements;
        hold on;
        for i = 1:6
            if ~isempty(r_clean_well{i})
                make_circle(r_clean_well{i}, 6, "k");
            end
        end
        make_circle(r_clean_well{rewarded_well}, 6, "m");
        c_hat_j = c_hat + randn(size(c_hat));
        plot(c_hat_j(:,1), c_hat_j(:,2), "-og", DisplayName="predicted");
        title(sprintf("%s Trial %d, Stage %s, Sess %s", animal, trial_ix, stage, sess));
    end
    %%
    %fprintf("Done trial %d of %d\n", trial_ix, num_trials);
    keep_rows(trial_ix) = true;
end

result_table = table(status_col, rewarded_well_col, stage_col, sess_col,...
    sess_type_col, sess_day_label_col,...
    rmse_to_reward, mean_dist_to_reward, min_dist_to_reward,...
    VariableNames=["Status" "Rewarded" "Stage" "Sess" "SessType" "SessDay", "RMSDist", "MeanDist", "MinDist"]);
result_table = result_table(keep_rows, :);
end

%%
function c = ks2centers(ks, box_dims, bin_nums)
ks = ks(:);
[i, j] = ind2sub(bin_nums, ks);
dpos = [i j];
c = dpos - 0.5;
c = c ./ bin_nums .* box_dims;
end

function make_circle(c, r, color)
arguments
    c (1,2) double
    r (1,1) double
    color
end
rectangle(Position=[(c-r), 2*r*[1 1]], Curvature=[1 1], FaceColor=color);
end
