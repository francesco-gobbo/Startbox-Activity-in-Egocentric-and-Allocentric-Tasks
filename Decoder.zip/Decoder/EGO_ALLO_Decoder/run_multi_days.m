mouse_name = "H2241";
exp_type = "Allo";
day_nums = setdiff(28:34,30); %[28:29, 31:34];
n_days = numel(day_nums);
[res, firing] = deal(cell(1,n_days));
runtime = zeros(1,n_days);
t_tot = tic;
for i = 1:n_days
    t_ = tic;
    [res{i}, firing{i}] = decoding_analysis(mouse_name, exp_type, day_nums(i));
    runtime(i) = toc(t_);
end
runtime_all = toc(t_tot);
fprintf("Total runtime: %.2g s\n", runtime_all);
%%
results_tab = struct2table(cat(2,res{:}));
figure;
plot(day_nums, results_tab.rmse_test, "bo-");
hold on;
plot(day_nums, results_tab.rmse_train, "bx-.");
plot(day_nums, results_tab.rmse_const, "ro-");
legend test train constant
legend Location best
ylim([0 Inf]);
xlabel 'Experiment Day'
ylabel 'Prediction RMSE (cm)'
title("Decoding: mouse " + mouse_name + " " + exp_type);