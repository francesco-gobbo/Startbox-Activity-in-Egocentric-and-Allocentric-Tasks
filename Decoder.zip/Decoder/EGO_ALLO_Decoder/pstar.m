function s = pstar(p)
if p >= 0.05
    s = "n.s.";
else
    n = -ceil(log10(p+eps));
    if n <= 3
        s = string(repmat('*',1,n));
    else
        s = "*x" + n;
    end
end