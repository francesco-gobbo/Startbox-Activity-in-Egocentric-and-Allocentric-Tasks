
# Code for decoding analysis in the Ego-Allo project

The MATLAB code here was used for decoding analyses in the Ego-Allo project. All code was written by Omer Hazon (hazon@stanford.edu).

The file `ego_vs_allo_test.m` contains the script for producing the `*_allo_ego_test.svg` figures, one for each animal, and `summary_all_*.svg` figures. It uses the results stored in `result_tables_save.mat`.

The file `test_all_rats.m` contains the script for generating `result_tables_save.mat` and calls the function in `apply_decoders.m`.
The function in `apply_decoders.m` relies on `decode_*.mat` and uses the previously trained decoders in those files.

The file `test_sess_decoders.m` contains the script for generating the `decode_*.mat` files. The decoding process itself is in the method found in `@OpenField/decode.m`. It also generates the figures `decoder_test_by_rat.svg` and `decoder_test_by_rat_diff.svg`.

The method in `@OpenField/decode.m` runs the decoding pipeline with training, validation, and testing.
